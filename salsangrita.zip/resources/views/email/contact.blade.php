<h2>Llegó una solicitud de contacto de Salsangrita.com</h2> 
<br>
    
<strong>Contacto </strong><br>
<strong>Nombre: </strong>{{ $data->name }} <br>
<strong>Correo: </strong>{{ $data->email }} <br>
<strong>Teléfono: </strong>{{ $data->phone }} <br>
<strong>Mensaje: </strong>{{ $data->message }} <br><br>
  
