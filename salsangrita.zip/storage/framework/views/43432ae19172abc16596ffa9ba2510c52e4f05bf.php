<h2>Llegó una solicitud de contacto de Salsangrita.com</h2> 
<br>
    
<strong>Contacto </strong><br>
<strong>Nombre: </strong><?php echo e($data->name); ?> <br>
<strong>Correo: </strong><?php echo e($data->email); ?> <br>
<strong>Teléfono: </strong><?php echo e($data->phone); ?> <br>
<strong>Mensaje: </strong><?php echo e($data->message); ?> <br><br>
  
<?php /**PATH C:\laragon\www\salsangrita\resources\views/email/contact.blade.php ENDPATH**/ ?>